"""
Dummy python module.
"""
