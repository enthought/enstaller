A very simple dummy Python project


